'use client';

import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import Header from './ui/Header';
import Sidebar from './ui/Sidebar';
import StatsCard from './ui/StatsCard';
import GameCard from './ui/GameCard';
import ChatSidebar from './ui/ChatSidebar';
import LoginModal from './ui/LoginModal';
import { CoinflipGame, ChatMessage } from '@/types';

interface CoinflipUIProps {
  onTabChange: (tab: string) => void;
}

const CoinflipUI: React.FC<CoinflipUIProps> = ({ onTabChange }) => {
  const [selectedSort, setSelectedSort] = useState<string>('Highest to Lowest');
  const [selectedGame, setSelectedGame] = useState<string>('All Games');
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);

  const coinflipGames: CoinflipGame[] = [
    {
      id: 1,
      player1: { name: 'Player1', avatar: '😊', level: 50 },
      player2: { name: 'Player2', avatar: '😎', level: 45 },
      items: ['🔥', '🔥', '🔥', '🔥'],
      extraItems: 4,
      value: '65.1K',
      range: '31.2K - 34.4K',
      pot: 'T',
      status: 'waiting'
    },
    {
      id: 2,
      player1: { name: 'Player3', avatar: '😄', level: 42 },
      player2: { name: 'Player4', avatar: '🤓', level: 38 },
      items: ['🔥', '🔥', '🔥'],
      extraItems: 0,
      value: '25.1K',
      range: '12.0K - 13.2K',
      pot: 'T',
      status: 'waiting'
    },
    {
      id: 3,
      player1: { name: 'Player5', avatar: '😏', level: 35 },
      player2: { name: '?', avatar: '❓', level: 0 },
      items: ['💎'],
      extraItems: 0,
      value: '23.5K',
      range: '22.3K - 24.7K',
      pot: '',
      status: 'open'
    },
    {
      id: 4,
      player1: { name: 'Player6', avatar: '😌', level: 48 },
      player2: { name: 'Player7', avatar: '🤔', level: 41 },
      items: ['🔥', '💜', '💜', '💜', '💚'],
      extraItems: 0,
      value: '12.8K',
      range: '6.0K - 6.6K',
      pot: 'T',
      status: 'waiting'
    },
    {
      id: 5,
      player1: { name: 'Player8', avatar: '😊', level: 44 },
      player2: { name: 'Player9', avatar: '😎', level: 39 },
      items: ['🔥', '🔥'],
      extraItems: 0,
      value: '12.6K',
      range: '6.0K - 6.6K',
      pot: 'T',
      status: 'waiting'
    },
    {
      id: 6,
      player1: { name: 'Player10', avatar: '🤗', level: 52 },
      player2: { name: 'Player11', avatar: '😄', level: 36 },
      items: ['🔥', '🔥'],
      extraItems: 0,
      value: '12.6K',
      range: '6.0K - 6.6K',
      pot: 'T',
      status: 'waiting'
    },
    {
      id: 7,
      player1: { name: 'Player12', avatar: '😏', level: 33 },
      player2: { name: 'Player13', avatar: '🤓', level: 47 },
      items: ['💜', '💜', '💜'],
      extraItems: 1,
      value: '10.8K',
      range: '5.2K - 5.8K',
      pot: '',
      status: 'waiting'
    }
  ];

  const chatMessages: ChatMessage[] = [
    { user: '@12WXY', message: 'lost 80k in 2 mins', time: '11:48', isVerified: true },
    { user: '@Elmantasvev123', message: 'Hhg', time: '11:49', isVerified: false },
    { user: '@12WXY', message: 'to easy', time: '11:49', isVerified: true },
    { user: '@Friday88667684348', message: 'can sumi tip me i lost 8.8k to a glitch i will probaly get the pets back soon so i can pb', time: '11:49', isVerified: true },
    { user: '@_LovekoCall', message: 'If someone can tip me i can flip.', time: '11:50', isVerified: true },
    { user: '@MaryBlast90', message: 'I tipped so many people and now I lost all :( can someone tip me 🥺❤️', time: '11:50', isVerified: true },
    { user: '@llomq_Killah', message: 'I have 60k in smalls onsite bro', time: '11:50', isVerified: false }
  ];

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 text-white">
        <Header onLoginClick={() => setShowLoginModal(true)} />
        
        <div className="flex">
          <Sidebar activeTab="coinflip" onTabChange={onTabChange} />
          
          {/* Main Content */}
          <div className="flex-1 p-6">
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              <StatsCard value="27" label="Rooms" />
              <StatsCard value="177.5K" label="Value" />
              <StatsCard value="70" label="Items" />
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex space-x-4">
                <button className="bg-purple-600 hover:bg-purple-700 px-6 py-2 rounded-lg font-semibold">
                  Create
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 px-6 py-2 rounded-lg font-semibold">
                  History
                </button>
              </div>
              
              <div className="flex space-x-4">
                <div className="relative">
                  <select 
                    value={selectedSort} 
                    onChange={(e) => setSelectedSort(e.target.value)}
                    className="bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 pr-8 appearance-none cursor-pointer"
                  >
                    <option>Highest to Lowest</option>
                    <option>Lowest to Highest</option>
                    <option>Newest First</option>
                  </select>
                  <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 pointer-events-none" />
                </div>
                
                <div className="relative">
                  <select 
                    value={selectedGame} 
                    onChange={(e) => setSelectedGame(e.target.value)}
                    className="bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 pr-8 appearance-none cursor-pointer"
                  >
                    <option>All Games</option>
                    <option>Open Games</option>
                    <option>Waiting Games</option>
                  </select>
                  <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Games List */}
            <div className="space-y-4">
              {coinflipGames.map((game) => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          </div>

          <ChatSidebar messages={chatMessages} />
        </div>
      </div>

      {/* Login Modal - Rendered outside the main container */}
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)} 
      />
    </>
  );
};

export default CoinflipUI;