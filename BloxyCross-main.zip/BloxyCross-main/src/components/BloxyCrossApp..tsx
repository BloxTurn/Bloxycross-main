'use client';

import React, { useState } from 'react';
import JackpotUI from './JackpotUI';  // ← Fix: Remove 'ui/' from path
import CoinflipUI from './CoinflipUI';

const BloxyCrossApp: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('coinflip');

  const handleTabChange = (tab: string) => {  // ← Add this function
    setActiveTab(tab);
  };

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'jackpot':
        return <JackpotUI onTabChange={handleTabChange} />;  // ← Add onTabChange prop
      case 'coinflip':
      default:
        return <CoinflipUI onTabChange={handleTabChange} />;  // ← Add onTabChange prop
    }
  };

  return (
    <div>
      {renderActiveComponent()}
    </div>
  );
};

export default BloxyCrossApp;