'use client';

import React, { useState } from 'react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const [username, setUsername] = useState<string>('');
  const [agreeToTerms, setAgreeToTerms] = useState<boolean>(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-8 w-96 relative">
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white text-xl"
        >
          ×
        </button>
        
        {/* Logo and Title */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center font-bold">BX</div>
            <span className="text-xl font-bold text-purple-400">BloxyCross</span>
          </div>
          <h2 className="text-2xl font-bold mb-4">Welcome to BloxyCross</h2>
          <p className="text-gray-400 text-sm mb-6">
            By logging in, you confirm you are at least 18, your items are not stolen, and you agree to our Terms of Service
          </p>
        </div>

        {/* Step Indicators */}
        <div className="flex items-center justify-center space-x-4 mb-6">
          <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold">
            1
          </div>
          <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center text-gray-400 font-bold">
            2
          </div>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Roblox Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your Roblox username..."
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="terms"
              checked={agreeToTerms}
              onChange={(e) => setAgreeToTerms(e.target.checked)}
              className="w-4 h-4 text-purple-600 bg-gray-700 border-gray-600 rounded focus:ring-purple-500"
            />
            <label htmlFor="terms" className="text-sm text-gray-300">
              I agree to the{' '}
              <span className="text-purple-400 hover:underline cursor-pointer">
                terms of service
              </span>
            </label>
          </div>

          <button
            disabled={!username || !agreeToTerms}
            className={`w-full py-3 rounded-lg font-semibold flex items-center justify-center space-x-2 ${
              username && agreeToTerms
                ? 'bg-purple-600 hover:bg-purple-700 text-white'
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            <span>Continue</span>
            <span>→</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginModal;