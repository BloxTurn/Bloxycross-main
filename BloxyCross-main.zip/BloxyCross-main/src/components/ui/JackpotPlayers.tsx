'use client';

import React from 'react';
import { JackpotPlayer } from '@/types';

interface JackpotPlayersProps {
  players: JackpotPlayer[];
}

const JackpotPlayers: React.FC<JackpotPlayersProps> = ({ players }) => {
  return (
    <div className="space-y-4 max-h-96 overflow-y-auto">
      {players.map((player) => (
        <div key={player.id} className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center text-xl">
                {player.avatar}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-white font-semibold">{player.username}</span>
                  <span 
                    className="px-2 py-1 rounded text-xs font-bold text-white"
                    style={{ backgroundColor: player.color }}
                  >
                    {player.percentage}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Items */}
              <div className="flex items-center space-x-1">
                {player.items.slice(0, 4).map((item, idx) => (
                  <div key={idx} className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center text-sm">
                    {item}
                  </div>
                ))}
                {player.itemCount > 4 && (
                  <div className="w-8 h-8 bg-gray-600 rounded-lg flex items-center justify-center text-xs font-bold">
                    +{player.itemCount - 4}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default JackpotPlayers;