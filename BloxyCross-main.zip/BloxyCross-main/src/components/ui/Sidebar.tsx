'use client';

import React from 'react';
import { Zap, Gift, MessageSquare, Users, Twitter } from 'lucide-react';

interface SidebarProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab = 'coinflip', onTabChange }) => {
  const handleTabClick = (tab: string) => {
    if (onTabChange) {
      onTabChange(tab);
    }
  };

  return (
    <div className="w-64 bg-gray-800/50 border-r border-gray-700 p-4">
      <div className="space-y-4">
        <div 
          className={`${
            activeTab === 'coinflip' 
              ? 'bg-purple-600/20 border border-purple-600' 
              : 'bg-gray-700/50 border border-gray-600'
          } rounded-lg p-4 cursor-pointer`}
          onClick={() => handleTabClick('coinflip')}
        >
          <div className={`flex items-center space-x-2 ${
            activeTab === 'coinflip' ? 'text-purple-400' : 'text-gray-400'
          } mb-2`}>
            <div className={`w-6 h-6 ${
              activeTab === 'coinflip' ? 'bg-purple-600' : 'bg-gray-600'
            } rounded-full`}></div>
            <span>Coinflip</span>
          </div>
        </div>
        
        <div 
          className={`${
            activeTab === 'jackpot' 
              ? 'bg-purple-600/20 border border-purple-600' 
              : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
          } cursor-pointer p-3 rounded-lg flex items-center space-x-2`}
          onClick={() => handleTabClick('jackpot')}
        >
          <Zap size={20} />
          <span>Jackpot</span>
        </div>
        
        <div className="text-gray-400 hover:text-white cursor-pointer p-3 rounded-lg hover:bg-gray-700/50 flex items-center space-x-2">
          <Gift size={20} />
          <span>Provably Fair</span>
        </div>
        
        <div className="text-gray-400 hover:text-white cursor-pointer p-3 rounded-lg hover:bg-gray-700/50 flex items-center space-x-2">
          <MessageSquare size={20} />
          <span>Terms of Service</span>
        </div>
        
        <div className="text-gray-400 hover:text-white cursor-pointer p-3 rounded-lg hover:bg-gray-700/50 flex items-center space-x-2">
          <Users size={20} />
          <span>Discord</span>
        </div>
        
        <div className="text-gray-400 hover:text-white cursor-pointer p-3 rounded-lg hover:bg-gray-700/50 flex items-center space-x-2">
          <Twitter size={20} />
          <span>Twitter</span>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;