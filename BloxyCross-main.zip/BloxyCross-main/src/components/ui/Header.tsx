'use client';

import React from 'react';
import { Home, Trophy } from 'lucide-react';

interface HeaderProps {
  onLoginClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLoginClick }) => {
  return (
    <div className="flex items-center justify-between p-4 border-b border-gray-700">
      <div className="flex items-center space-x-8">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center font-bold">BX</div>
          <span className="text-xl font-bold text-purple-400">BloxyCross</span>
        </div>
        <nav className="flex items-center space-x-6">
          <div className="flex items-center space-x-2 text-gray-300 hover:text-white cursor-pointer">
            <Home size={20} />
            <span>Home</span>
          </div>
          <div className="flex items-center space-x-2 text-gray-300 hover:text-white cursor-pointer">
            <Trophy size={20} />
            <span>Leaderboard</span>
          </div>
        </nav>
      </div>
      <button 
        onClick={onLoginClick}
        className="bg-purple-600 hover:bg-purple-700 px-6 py-2 rounded-lg font-semibold"
      >
        LOGIN
      </button>
    </div>
  );
};

export default Header;