'use client';

import React from 'react';
import { ChatMessage } from '@/types';

interface ChatSidebarProps {
  messages: ChatMessage[];
}

const ChatSidebar: React.FC<ChatSidebarProps> = ({ messages }) => {
  return (
    <div className="w-80 bg-gray-800/50 border-l border-gray-700 p-4">
      <div className="space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className="flex items-start space-x-2">
            <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center text-sm">
              👤
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <span className={`text-sm font-semibold ${msg.isVerified ? 'text-red-400' : 'text-blue-400'}`}>
                  {msg.user}
                </span>
                {msg.isVerified && <span className="text-red-400">⚠️</span>}
                <span className="text-xs text-gray-500">{msg.time}</span>
              </div>
              <p className="text-sm text-gray-300">{msg.message}</p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-700">
        <div className="text-center text-gray-400 text-sm mb-4">Login to chat</div>
        <div className="flex items-center justify-center space-x-2 text-green-400">
          <div className="w-2 h-2 bg-green-400 rounded-full"></div>
          <span className="text-sm">178</span>
        </div>
      </div>
    </div>
  );
};

export default ChatSidebar;