'use client';

import React from 'react';
import { CoinflipGame } from '@/types';

interface GameCardProps {
  game: CoinflipGame;
}

const GameCard: React.FC<GameCardProps> = ({ game }) => {
  return (
    <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        {/* Player 1 */}
        <div className="flex items-center space-x-2">
          <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center text-xl">
            {game.player1.avatar}
          </div>
          <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-xs font-bold">
            {game.player1.level}
          </div>
        </div>

        <span className="text-gray-400 font-bold text-xl">VS</span>

        {/* Player 2 */}
        <div className="flex items-center space-x-2">
          <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center text-xl">
            {game.player2.avatar}
          </div>
          {game.player2.level > 0 && (
            <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-xs font-bold">
              {game.player2.level}
            </div>
          )}
        </div>

        {/* Items */}
        <div className="flex items-center space-x-1">
          {game.items.map((item, idx) => (
            <div key={idx} className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center text-lg">
              {item}
            </div>
          ))}
          {game.extraItems > 0 && (
            <div className="w-10 h-10 bg-gray-600 rounded-lg flex items-center justify-center text-sm font-bold">
              +{game.extraItems}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center space-x-6">
        {/* Value */}
        <div className="text-center">
          <div className="flex items-center space-x-2 mb-1">
            <div className="w-6 h-6 bg-purple-600 rounded"></div>
            <span className="text-2xl font-bold">{game.value}</span>
          </div>
          <div className="text-sm text-gray-400">{game.range}</div>
        </div>

        {/* Pot indicator */}
        {game.pot && (
          <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center font-bold">
            {game.pot}
          </div>
        )}

        {/* Action Button */}
        <button 
          className={`px-6 py-2 rounded-lg font-semibold ${
            game.status === 'open' 
              ? 'bg-purple-600 hover:bg-purple-700' 
              : 'bg-gray-600 hover:bg-gray-500'
          }`}
        >
          {game.status === 'open' ? 'Join' : 'View'}
        </button>
      </div>
    </div>
  );
};

export default GameCard;