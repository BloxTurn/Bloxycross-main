'use client';

import React from 'react';
import { JackpotPlayer } from '@/types';

interface JackpotWheelProps {
  players: JackpotPlayer[];
  totalValue: string;
  timeRemaining: string;
}

const JackpotWheel: React.FC<JackpotWheelProps> = ({ players, totalValue, timeRemaining }) => {
  // Calculate wheel segments based on player percentages
  const getWheelSegments = () => {
    let currentAngle = 0;
    return players.map((player, index) => {
      const percentage = parseFloat(player.percentage);
      const angle = (percentage / 100) * 360;
      const segment = {
        ...player,
        startAngle: currentAngle,
        endAngle: currentAngle + angle,
        angle: angle
      };
      currentAngle += angle;
      return segment;
    });
  };

  const segments = getWheelSegments();

  // Generate SVG path for each segment
  const generatePath = (startAngle: number, endAngle: number) => {
    const centerX = 200;
    const centerY = 200;
    const radius = 180;
    const innerRadius = 80;

    const startAngleRad = (startAngle * Math.PI) / 180;
    const endAngleRad = (endAngle * Math.PI) / 180;

    const x1 = centerX + radius * Math.cos(startAngleRad);
    const y1 = centerY + radius * Math.sin(startAngleRad);
    const x2 = centerX + radius * Math.cos(endAngleRad);
    const y2 = centerY + radius * Math.sin(endAngleRad);

    const x3 = centerX + innerRadius * Math.cos(endAngleRad);
    const y3 = centerY + innerRadius * Math.sin(endAngleRad);
    const x4 = centerX + innerRadius * Math.cos(startAngleRad);
    const y4 = centerY + innerRadius * Math.sin(startAngleRad);

    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';

    return `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} L ${x3} ${y3} A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${x4} ${y4} Z`;
  };

  // Get avatar position on the wheel
  const getAvatarPosition = (startAngle: number, endAngle: number) => {
    const midAngle = (startAngle + endAngle) / 2;
    const avatarRadius = 130;
    const centerX = 200;
    const centerY = 200;
    
    const angleRad = (midAngle * Math.PI) / 180;
    const x = centerX + avatarRadius * Math.cos(angleRad);
    const y = centerY + avatarRadius * Math.sin(angleRad);
    
    return { x, y };
  };

  return (
    <div className="flex items-center justify-center">
      <div className="relative">
        <svg width="400" height="400" className="transform -rotate-90">
          {segments.map((segment, index) => (
            <g key={segment.id}>
              <path
                d={generatePath(segment.startAngle, segment.endAngle)}
                fill={segment.color}
                stroke="#1f2937"
                strokeWidth="2"
              />
            </g>
          ))}
        </svg>
        
        {/* Player avatars positioned on the wheel */}
        {segments.map((segment) => {
          const { x, y } = getAvatarPosition(segment.startAngle, segment.endAngle);
          return (
            <div
              key={segment.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: x, top: y }}
            >
              <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center text-xl border-2 border-white">
                {segment.avatar}
              </div>
            </div>
          );
        })}

        {/* Center circle with total value and timer */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-32 h-32 bg-gray-800 rounded-full flex flex-col items-center justify-center border-4 border-gray-600">
            <div className="flex items-center space-x-1 mb-1">
              <div className="w-4 h-4 bg-purple-600 rounded"></div>
              <span className="text-white font-bold text-lg">{totalValue}</span>
            </div>
            <div className="text-gray-400 text-sm">{timeRemaining}</div>
          </div>
        </div>

        {/* Winner indicator line */}
        <div className="absolute top-1/2 right-0 transform -translate-y-1/2 translate-x-2">
          <div className="w-6 h-1 bg-white"></div>
        </div>
      </div>
    </div>
  );
};

export default JackpotWheel;