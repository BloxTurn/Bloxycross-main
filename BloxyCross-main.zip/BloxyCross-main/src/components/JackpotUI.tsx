'use client';

import React, { useState } from 'react';
import { JackpotPlayer, ChatMessage } from '@/types';
import Header from './ui/Header';
import Sidebar from './ui/Sidebar';  // ← FIXED: Import your custom Sidebar component
import JackpotWheel from './ui/JackpotWheel';
import JackpotPlayers from './ui/JackpotPlayers';
import ChatSidebar from './ui/ChatSidebar';
import LoginModal from './ui/LoginModal';

interface JackpotUIProps {
  onTabChange: (tab: string) => void;
}

const JackpotUI: React.FC<JackpotUIProps> = ({ onTabChange }) => {  
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);

  const jackpotPlayers: JackpotPlayer[] = [
    {
      id: 1,
      username: 'm4str1y',
      avatar: '😊',
      items: ['💜', '💜', '💜', '💜'],
      itemCount: 12,
      percentage: '7.91%',
      value: 1200,
      color: '#ef4444' // red
    },
    {
      id: 2,
      username: 'DoggyToInfinityBoiii',
      avatar: '🤠',
      items: ['💜', '💜', '💜', '💜'],
      itemCount: 8,
      percentage: '11.86%',
      value: 1800,
      color: '#f97316' // orange
    },
    {
      id: 3,
      username: 'Player3',
      avatar: '😎',
      items: ['💎', '💎', '💎'],
      itemCount: 6,
      percentage: '25.4%',
      value: 3850,
      color: '#eab308' // yellow
    },
    {
      id: 4,
      username: 'Player4',
      avatar: '🤓',
      items: ['🔥', '🔥'],
      itemCount: 4,
      percentage: '15.2%',
      value: 2300,
      color: '#22c55e' // green
    },
    {
      id: 5,
      username: 'Player5',
      avatar: '😏',
      items: ['💜'],
      itemCount: 3,
      percentage: '8.9%',
      value: 1350,
      color: '#06b6d4' // cyan
    },
    {
      id: 6,
      username: 'Player6',
      avatar: '🤗',
      items: ['🔥', '🔥', '🔥'],
      itemCount: 5,
      percentage: '18.7%',
      value: 2830,
      color: '#8b5cf6' // purple
    },
    {
      id: 7,
      username: 'Player7',
      avatar: '😌',
      items: ['💎'],
      itemCount: 2,
      percentage: '11.94%',
      value: 1810,
      color: '#ec4899' // pink
    }
  ];

  const chatMessages: ChatMessage[] = [
    { user: '@zeus', message: 'u cant let a downsyndrome like that', time: '16:24', isVerified: false },
    { user: '@llomq_Killah', message: 'Depoing for people, join llomq_killah to depo quickly, only if 1.8k+ value items.', time: '16:24', isVerified: false },
    { user: '@redbullsegaming', message: '@verz slide me 100 ill be so happy', time: '16:24', isVerified: true },
    { user: '@DGrock23alt', message: 'PLEASE TIP ME SMTH SMALL', time: '16:24', isVerified: false },
    { user: '@VerzaKid', message: 'amazing nigga', time: '16:24', isVerified: false },
    { user: '@NothingToSmith', message: 'W VERZ', time: '16:24', isVerified: true },
    { user: '@MeggyToSecret_193', message: 'w verz', time: '16:24', isVerified: true },
    { user: '@theproofamongus', message: 'W VERZ', time: '16:24', isVerified: true }
  ];

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 text-white">
        <Header onLoginClick={() => setShowLoginModal(true)} />
        
        <div className="flex">
          <Sidebar activeTab="jackpot" onTabChange={onTabChange} />
          
          {/* Main Content */}
          <div className="flex-1 p-6">
            {/* Jackpot Wheel */}
            <div className="mb-8">
              <JackpotWheel 
                players={jackpotPlayers}
                totalValue="15.17K"
                timeRemaining="24 | 0s"
              />
            </div>

            {/* Players List */}
            <div className="grid grid-cols-2 gap-6">
              {/* <div>
                <h3 className="text-xl font-bold mb-4">Players ({jackpotPlayers.length})</h3>
                <JackpotPlayers players={jackpotPlayers} />
              </div> */}
              
              {/* Additional info or controls can go here */}
              <div>
                <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                  {/* <h3 className="text-lg font-bold mb-4">Jackpot Info</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Value:</span>
                      <span className="text-white font-bold">15.17K</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Players:</span>
                      <span className="text-white">{jackpotPlayers.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Time Remaining:</span>
                      <span className="text-white">24s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Min Bet:</span>
                      <span className="text-white">100</span>
                    </div>
                  </div> */}
                  
                  <button className="w-full mt-6 bg-purple-600 hover:bg-purple-700 py-3 rounded-lg font-semibold">
                    Place a bet
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ChatSidebar messages={chatMessages} />
        </div>
      </div>

      {/* Login Modal */}
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)} 
      />
    </>
  );
};

export default JackpotUI;