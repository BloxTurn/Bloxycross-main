import BloxyCrossApp from "@/components/BloxyCrossApp.";
import CoinflipUI from "@/components/CoinflipUI";

export default function Home() {
  // return <CoinflipUI />
  return <BloxyCrossApp />;
}
