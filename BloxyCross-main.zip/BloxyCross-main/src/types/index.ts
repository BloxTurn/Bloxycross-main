export interface Player {
  name: string;
  avatar: string;
  level: number;
}

export interface CoinflipGame {
  id: number;
  player1: Player;
  player2: Player;
  items: string[];
  extraItems: number;
  value: string;
  range: string;
  pot: string;
  status: 'waiting' | 'open';
}

export interface ChatMessage {
  user: string;
  message: string;
  time: string;
  isVerified: boolean;
}

export interface JackpotPlayer {
  id: number;
  username: string;
  avatar: string;
  items: string[];
  itemCount: number;
  percentage: string;
  value: number;
  color: string;
}

export interface JackpotGame {
  totalValue: string;
  timeRemaining: string;
  players: JackpotPlayer[];
  isActive: boolean;
}